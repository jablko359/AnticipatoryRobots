classdef obstacle
    properties
        x   %position
        t   %time when obstacle is acticated
        s   %severity
        r   %effort of removal
        L   %length x2
        a = 0  %isActive
    end
end