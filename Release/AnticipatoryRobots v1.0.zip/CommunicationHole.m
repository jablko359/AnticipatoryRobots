classdef CommunicationHole
        
    properties
        x
        L
        r   %how much range is reduced (0-1)
    end   
end

