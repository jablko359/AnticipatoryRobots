addpath(genpath('.\'))
a = mojeGUI();

